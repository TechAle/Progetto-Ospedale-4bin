﻿using System;

namespace ospedale
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            ospedale_cls ospedale = new ospedale_cls();

            ospedale.carica_csv();
        }
    }
}

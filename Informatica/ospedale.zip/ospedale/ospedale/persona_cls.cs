﻿using System;
namespace ospedale
{
    public class persona_cls
    {
        // Variabile standard di una persona
        public string nome;
        public string cognome;
        public string data_di_nascita;
    }
}
